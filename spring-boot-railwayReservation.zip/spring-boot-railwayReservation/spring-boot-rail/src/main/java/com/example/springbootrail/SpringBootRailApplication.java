package com.example.springbootrail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.example"})
public class SpringBootRailApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRailApplication.class, args);
	}

}
