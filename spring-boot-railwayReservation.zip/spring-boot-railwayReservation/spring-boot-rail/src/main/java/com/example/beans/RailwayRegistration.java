package com.example.beans;

/**
 * @author krishnakanth
 *
 */
public class RailwayRegistration {
	


	String name;
	int age;
	String gender;
	String birthpreference;
	int conformedTickets;
	int RAC;
	int waitingList;
	int NotConformed;
	int lowerBirth;
	
	
	
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public int getAge() {
	return age;
	}
	public void setAge(int age) {
	this.age = age;
	}
	
	public String getGender() {
	return gender;
	}
	public void setGender(String gender) {
	this.gender = gender;
	}
	
	public String getBirthpreference() {
		return birthpreference;
	}
	public void setBirthpreference(String birthpreference) {
		this.birthpreference = birthpreference;
	}
	public void setBirthpreference(RailwayRegistration railregregd) {
		// TODO Auto-generated method stub
		
	}
	

	public int getConformedTickets() {
		return conformedTickets;
	}
	public void setConformedTickets(int conformedTickets) {
		this.conformedTickets = conformedTickets;
	}
	public int getRAC() {
		return RAC;
	}
	public void setRAC(int rAC) {
		RAC = rAC;
	}
	public int getWaitingList() {
		return waitingList;
	}
	public void setWaitingList(int waitingList) {
		this.waitingList = waitingList;
	}
	
	public int getNotConformed() {
		return NotConformed;
	}
	public void setNotConformed(int notConformed) {
		NotConformed = notConformed;
	}
	public int getLowerBirth() {
		return lowerBirth;
	}
	public void setLowerBirth(int lowerBirth) {
		this.lowerBirth = lowerBirth;
	}



}
