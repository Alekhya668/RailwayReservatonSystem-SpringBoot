package com.example.rest.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.beans.RailwayRegistration;
 

@Controller
public class RailwayRegisterController {
	@RequestMapping(method = RequestMethod.POST, value="/register/railway")
	@ResponseBody
	RailwayRegistration registerRailway(@RequestBody RailwayRegistration railregregd) {
	RailwayRegistration railregreply = new RailwayRegistration();
	railregreply.setName(railregregd.getName());
	railregreply.setAge(railregregd.getAge());
	railregreply.setGender(railregregd.getGender());
	railregreply.setBirthpreference(railregregd.getBirthpreference());
	railregreply.setConformedTickets(railregregd.getConformedTickets());
	railregreply.setWaitingList(railregregd.getWaitingList());

	if (railregreply.equals(railregreply)) {
		if (railregreply.getAge()<5) {
			System.out.println("Details saved but not conform because age is less than 5 years: "+ railregreply.getAge());
			railregreply.setNotConformed(railregregd.getNotConformed());
		}
		if (railregreply.getConformedTickets()>32) {
			System.out.println("Before RAC: "+railregreply.getRAC());

			railregreply.setRAC(railregregd.getRAC());
			System.out.println("After RAC: "+railregreply.getRAC());
		}
		if (railregreply.getRAC()==1) {
			System.out.println("Yes");
		}else {
			System.out.println("No");
		}
		if (railregreply.getWaitingList()>5) {
			System.out.println("No");
		}
		if (railregreply.getAge()>60 ) {
			System.out.println("Lower Birth is assignrd");
			railregreply.setLowerBirth(railregregd.getLowerBirth());
		}
		System.out.println("This is After if statement of RAC");
		System.out.println("Railway Name: "+railregreply.getName());
		System.out.println("Railway Age: "+railregreply.getAge());
		System.out.println("Railway Gender: "+railregreply.getGender());
		System.out.println("Railway BirthPreference: "+railregreply.getBirthpreference());
		System.out.println("Railway conformedTickets: "+railregreply.getConformedTickets());
		System.out.println("Railway WaitingList: "+railregreply.getWaitingList());
	}
	return railregreply;
	
	
	}
}

