package com.example.springbootrail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRailApplicationTests {

	@Test
	void contextLoads() {
	}

}
